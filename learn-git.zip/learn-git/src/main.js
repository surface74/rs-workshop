const hello = () => alert("hello");
