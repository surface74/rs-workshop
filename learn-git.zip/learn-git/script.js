const sayHi = name => alert("Hi, " + name);
const work = name =>  {
  alert("Work!!");
  //https://www.youtube.com/watch?v=6oZG-pAeHRE&list=PLDyvV36pndZFHXjXuwA_NywNrVQO0aQqb&index=15
};
const sayBye = name => alert("Bye, " + name);